'use strict';
const $ = s => document.querySelector(s);
const DAYS = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const TYPES = {power:'Electricity', gas:'Gas', water:'Water'};
const COLORS = {power:'#F0B400', gas:'#E2552B', water:'#1B8BC9'};
let slots = [], bills = [];

/* ---------- IndexedDB ---------- */
const DB = {
  db: null,
  open() {
    return new Promise((ok, fail) => {
      const r = indexedDB.open('bijli-tracker', 1);
      r.onupgradeneeded = () => {
        ['slots','bills'].forEach(n => r.result.createObjectStore(n, {keyPath:'id', autoIncrement:true}));
      };
      r.onsuccess = () => { this.db = r.result; ok(); };
      r.onerror = () => fail(r.error);
    });
  },
  run(store, mode, fn) {
    return new Promise((ok, fail) => {
      const t = this.db.transaction(store, mode), q = fn(t.objectStore(store));
      t.oncomplete = () => ok(q && q.result);
      t.onerror = () => fail(t.error);
    });
  },
  all: s => DB.run(s, 'readonly', o => o.getAll()),
  add: (s, v) => DB.run(s, 'readwrite', o => o.add(v)),
  del: (s, id) => DB.run(s, 'readwrite', o => o.delete(id)),
  clear: s => DB.run(s, 'readwrite', o => o.clear())
};

/* ---------- Schedule logic ---------- */
function intervals(now = new Date()) {
  const out = [];
  for (let d = -1; d <= 7; d++) {
    const day = new Date(now.getFullYear(), now.getMonth(), now.getDate() + d);
    for (const s of slots) {
      if (!s.days.includes(day.getDay())) continue;
      const [sh, sm] = s.start.split(':').map(Number), [eh, em] = s.end.split(':').map(Number);
      const start = new Date(day.getFullYear(), day.getMonth(), day.getDate(), sh, sm);
      let end = new Date(day.getFullYear(), day.getMonth(), day.getDate(), eh, em);
      if (end <= start) end = new Date(end.getTime() + 864e5); // crosses midnight
      out.push({id: s.id, start, end});
    }
  }
  return out.sort((a, b) => a.start - b.start);
}
function span(ms) {
  const m = Math.max(0, Math.round(ms / 60000)), d = Math.floor(m / 1440), h = Math.floor(m % 1440 / 60);
  return (d ? d + 'd ' : '') + (h ? h + 'h ' : '') + (m % 60) + 'm';
}
const hhmm = d => d.toLocaleTimeString([], {hour:'numeric', minute:'2-digit'});

function tick() {
  const now = new Date(), list = intervals(now);
  const cur = list.find(i => i.start <= now && now < i.end);
  const next = list.find(i => i.start > now);
  const st = $('#state'), dt = $('#detail');
  if (!slots.length) {
    st.className = 'state'; st.textContent = 'No schedule yet';
    dt.textContent = 'Add your area\u2019s load shedding slots below.';
  } else if (cur) {
    st.className = 'state off'; st.textContent = 'Power is off';
    dt.textContent = `Back at ${hhmm(cur.end)}, in ${span(cur.end - now)}.`;
  } else {
    st.className = 'state on'; st.textContent = 'Power is on';
    dt.textContent = next ? `Next cut at ${hhmm(next.start)}, in ${span(next.start - now)}.` : 'No cuts in the next 7 days.';
  }
  remindCheck(now, next);
}

/* ---------- Reminders ---------- */
function notified() { try { return JSON.parse(localStorage.notified || '{}'); } catch { return {}; } }
async function remindCheck(now, next) {
  if (!next || !('Notification' in window) || Notification.permission !== 'granted') return;
  const lead = +($('#lead').value);
  const left = next.start - now;
  const key = next.id + '@' + next.start.getTime();
  const seen = notified();
  if (left > lead * 60000 || seen[key]) return;
  seen[key] = Date.now();
  for (const k in seen) if (Date.now() - seen[k] > 864e5 * 3) delete seen[k];
  localStorage.notified = JSON.stringify(seen);
  const body = `Power goes off at ${hhmm(next.start)} (${span(left)} from now). Charge your devices.`;
  const reg = navigator.serviceWorker && await navigator.serviceWorker.getRegistration();
  if (reg) reg.showNotification('Load shedding soon', {body, icon: 'icon.svg', tag: key});
  else new Notification('Load shedding soon', {body});
}
function notifUI() {
  const b = $('#notif'), n = $('#notif-note');
  if (!('Notification' in window)) { b.hidden = true; n.textContent = 'This browser does not support notifications.'; return; }
  const p = Notification.permission;
  b.hidden = p === 'granted';
  n.textContent = p === 'granted'
    ? 'Reminders are on. They fire while the app is open or running in the background. Keep it installed and pinned.'
    : p === 'denied' ? 'Notifications are blocked. Allow them in your browser\u2019s site settings.' : '';
}

/* ---------- Schedule UI ---------- */
function renderSlots() {
  const ul = $('#slots');
  ul.innerHTML = '';
  if (!slots.length) { ul.innerHTML = '<li class="note">Nothing here. Pick the days, set the times and press Add slot.</li>'; return; }
  for (const s of slots.slice().sort((a, b) => a.start.localeCompare(b.start))) {
    const li = document.createElement('li');
    const d = s.days.length === 7 ? 'Every day' : s.days.map(i => DAYS[i]).join(', ');
    li.innerHTML = `<span><b>${s.start}\u2013${s.end}</b> &nbsp;${d}</span>`;
    const x = document.createElement('button');
    x.className = 'ghost'; x.textContent = 'Remove'; x.setAttribute('aria-label', `Remove slot ${s.start} to ${s.end}`);
    x.onclick = async () => { await DB.del('slots', s.id); await load(); };
    li.append(x); ul.append(li);
  }
}

/* ---------- Bills ---------- */
const pkr = n => Math.round(n).toLocaleString('en-PK');
const monthLabel = m => new Date(m + '-01T00:00').toLocaleDateString([], {month:'short', year:'numeric'});
const monthKey = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');

function renderBills() {
  const tb = $('#bills tbody');
  tb.innerHTML = '';
  $('#empty').hidden = bills.length > 0;
  $('#bills').hidden = !bills.length;
  for (const b of bills.slice().sort((a, c) => c.month.localeCompare(a.month) || a.type.localeCompare(c.type))) {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${monthLabel(b.month)}</td><td><span class="dot" style="--c:${COLORS[b.type]}"></span>${TYPES[b.type]}</td>
      <td class="n">${b.units}</td><td class="n">${pkr(b.amount)}</td><td class="n">${b.units ? (b.amount / b.units).toFixed(1) : '-'}</td><td></td>`;
    const x = document.createElement('button');
    x.className = 'ghost'; x.textContent = 'Delete'; x.setAttribute('aria-label', `Delete ${TYPES[b.type]} bill for ${monthLabel(b.month)}`);
    x.onclick = async () => { if (confirm('Delete this bill?')) { await DB.del('bills', b.id); await load(); } };
    tr.lastElementChild.append(x); tb.append(tr);
  }
  const now = new Date(), cur = monthKey(now), prev = monthKey(new Date(now.getFullYear(), now.getMonth() - 1, 1));
  const sum = m => bills.filter(b => b.month === m).reduce((t, b) => t + b.amount, 0);
  const c = sum(cur), p = sum(prev);
  $('#summary').textContent = !bills.length ? '' :
    `${monthLabel(cur)}: PKR ${pkr(c)}` + (p ? ` \u2014 ${c >= p ? 'up' : 'down'} PKR ${pkr(Math.abs(c - p))} from ${monthLabel(prev)}` : '');
  drawChart();
}

function drawChart() {
  const cv = $('#chart'), r = devicePixelRatio || 1, w = cv.clientWidth, h = cv.clientHeight;
  cv.width = w * r; cv.height = h * r;
  const g = cv.getContext('2d'); g.scale(r, r); g.clearRect(0, 0, w, h);
  cv.hidden = !bills.length; if (!bills.length) return;
  const now = new Date(), months = [];
  for (let i = 5; i >= 0; i--) months.push(monthKey(new Date(now.getFullYear(), now.getMonth() - i, 1)));
  const totals = months.map(m => Object.keys(TYPES).map(t => bills.filter(b => b.month === m && b.type === t).reduce((s, b) => s + b.amount, 0)));
  const max = Math.max(1, ...totals.map(a => a.reduce((s, v) => s + v, 0)));
  const L = 48, B = 22, T = 8, bw = (w - L) / months.length;
  g.font = '12px "Segoe UI",system-ui,sans-serif'; g.fillStyle = '#5B6B7F'; g.strokeStyle = '#C9D3DE';
  for (let i = 0; i <= 4; i++) {
    const y = T + (h - B - T) * (1 - i / 4);
    g.beginPath(); g.moveTo(L, y); g.lineTo(w, y); g.stroke();
    g.textAlign = 'right'; g.fillText(pkr(max * i / 4), L - 6, y + 4);
  }
  g.textAlign = 'center';
  months.forEach((m, i) => {
    let y = h - B; const x = L + i * bw + bw * .2;
    totals[i].forEach((v, k) => {
      const ht = (h - B - T) * v / max; g.fillStyle = Object.values(COLORS)[k];
      g.fillRect(x, y - ht, bw * .6, ht); y -= ht;
    });
    g.fillStyle = '#5B6B7F'; g.fillText(new Date(m + '-01T00:00').toLocaleDateString([], {month:'short'}), x + bw * .3, h - 6);
  });
}

/* ---------- Data ---------- */
async function load() {
  [slots, bills] = await Promise.all([DB.all('slots'), DB.all('bills')]);
  renderSlots(); renderBills(); tick();
}

function bind() {
  const dg = document.querySelector('.days');
  DAYS.forEach((d, i) => {
    const l = document.createElement('label');
    l.innerHTML = `<input type="checkbox" value="${i}" checked><span>${d}</span>`;
    dg.append(l);
  });
  $('#b-month').value = monthKey(new Date());
  $('#lead').value = localStorage.lead || '15';
  $('#lead').onchange = () => localStorage.lead = $('#lead').value;

  $('#slot-form').onsubmit = async e => {
    e.preventDefault();
    const days = [...dg.querySelectorAll('input:checked')].map(i => +i.value);
    if (!days.length) return alert('Select at least one day.');
    const start = $('#s-start').value, end = $('#s-end').value;
    if (start === end) return alert('Start and end time cannot be the same.');
    await DB.add('slots', {days, start, end}); await load();
  };
  $('#bill-form').onsubmit = async e => {
    e.preventDefault();
    const type = $('#b-type').value, month = $('#b-month').value;
    const dup = bills.find(b => b.type === type && b.month === month);
    if (dup && !confirm(`A ${TYPES[type]} bill for ${monthLabel(month)} exists. Replace it?`)) return;
    if (dup) await DB.del('bills', dup.id);
    await DB.add('bills', {type, month, units: +$('#b-units').value, amount: +$('#b-amt').value});
    e.target.querySelectorAll('input[type=number]').forEach(i => i.value = '');
    await load();
  };
  $('#notif').onclick = async () => { await Notification.requestPermission(); notifUI(); tick(); };

  $('#export').onclick = () => {
    const strip = a => a.map(({id, ...r}) => r);
    const blob = new Blob([JSON.stringify({v:1, slots:strip(slots), bills:strip(bills)}, null, 2)], {type:'application/json'});
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = `bijli-tracker-${monthKey(new Date())}.json`; a.click();
    URL.revokeObjectURL(a.href);
  };
  $('#import').onchange = async e => {
    const f = e.target.files[0]; if (!f) return;
    try {
      const d = JSON.parse(await f.text());
      if (!Array.isArray(d.slots) || !Array.isArray(d.bills)) throw 0;
      if (!confirm('Importing replaces your current data. Continue?')) return;
      await DB.clear('slots'); await DB.clear('bills');
      for (const s of d.slots) await DB.add('slots', {days:s.days, start:s.start, end:s.end});
      for (const b of d.bills) await DB.add('bills', {type:b.type, month:b.month, units:+b.units, amount:+b.amount});
      await load();
    } catch { alert('That file is not a Bijli Tracker backup.'); }
    e.target.value = '';
  };
  addEventListener('resize', drawChart);
}

(async () => {
  await DB.open(); bind(); notifUI(); await load();
  setInterval(tick, 15000);
  document.addEventListener('visibilitychange', tick);
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});
})();
